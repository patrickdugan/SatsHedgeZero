import MathCan.ZKLeanLocal
open MathCan.ZKLean MathCan.ZKLean.Poly MathCan.ZKLean.Local

def targetGlobal : Nat := 4
def targetRow : Row := ⟨[⟨99997, 1⟩], [⟨0, 1⟩], []⟩
def refs : List (Nat × Row) := [(0, ⟨[⟨99995, 1⟩], [⟨0, 1⟩], []⟩), (2, ⟨[⟨99995, 1⟩], [⟨99996, 1⟩], [⟨99997, 1⟩]⟩)]
def weights : List Multiplier := [⟨(1), [99996], ⟨[⟨99995, 1⟩], [⟨0, 1⟩], []⟩⟩, ⟨(21888242871839275222246405745257275088548364400416034343698204186575808495616), [], ⟨[⟨99995, 1⟩], [⟨99996, 1⟩], [⟨99997, 1⟩]⟩⟩]
def correction : PPoly := [⟨[99995, 99996], (-1)⟩, ⟨[99997], (1)⟩]
def contextHeader : Shape := ⟨21888242871839275222246405745257275088548364400416034343698204186575808495617, 100003, [1, 2], []⟩

set_option maxRecDepth 4096 in
set_option maxHeartbeats 4000000 in
theorem indexed_context_delete (globalRows : List Row)
    (hs : wellFormed (withRows contextHeader globalRows))
    (hi : targetGlobal < globalRows.length)
    (ht : globalRows[targetGlobal]? = some targetRow)
    (hpos : ∀ q ∈ refs, q.1 ≠ targetGlobal ∧ globalRows[q.1]? = some q.2)
    (x : List Nat) :
    accepts (withRows contextHeader globalRows) x ↔
      accepts (withRows contextHeader (globalRows.eraseIdx targetGlobal)) x := by
  exact checked_indexed_poly_delete (withRows contextHeader globalRows) targetGlobal
    targetRow refs weights correction hs hi ht hpos (by decide)
    (by change polyCheck contextHeader.modulus targetRow weights correction = true; decide) x

#print axioms indexed_context_delete
